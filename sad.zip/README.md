# 💖 จีบเธอ - เกมขอความรักจากแฟน 💖
## 🎮 วิธีเล่น

1. เข้าไปที่ [จีบเธอ Game](https://axiostq.github.io/game-y-n/)

4. ถ้าคุณลองกดปุ่ม... เอ่อ ... ลองดูสิว่าจะเกิดอะไรขึ้น! 😉

## 💻 เทคโนโลยีที่ใช้

- HTML
- CSS
- JavaScript
  
## 👨‍💻 การพัฒนา
สนใจที่จะลองทำบ้างลอง Pull Requests! โดยลองทำตามขั้นตอนนี้:
1. เปิด command prompt
2. ใช้คำสั่ง git clone https://github.com/axiostq/game-y-n.git
3. รันได้เลย!!


## 📬 ติดต่อ
[Tiktok](https://www.tiktok.com/@axiostq)


---

สร้างด้วย ❤️ โดย Axoistq
